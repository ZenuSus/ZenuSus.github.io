import pygame
import json
import os
import time
import random
from pygame import mixer

# Инициализация pygame
pygame.init()
mixer.init()

# Размеры окна
WIDTH, HEIGHT = 1200, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Симулятор шаурмичной 🌯✅")

# Цвета
DARK_BG = (25, 25, 35)
ACCENT = (255, 105, 0)
GREEN = (50, 205, 50)
RED = (220, 20, 60)
GOLD = (255, 215, 0)
LIGHT_BG = (45, 45, 60, 200)
WHITE = (240, 240, 240)
GRAY = (180, 180, 180)
DARK_ORANGE = (235, 85, 0)
BLUE = (30, 144, 255)
ORANGE = (255, 165, 0)

# Шрифты
try:
    title_font = pygame.font.Font(None, 42)
    font_large = pygame.font.Font(None, 30)
    font = pygame.font.Font(None, 24)
    font_small = pygame.font.Font(None, 20)
except:
    title_font = pygame.font.SysFont('Arial', 42)
    font_large = pygame.font.SysFont('Arial', 30)
    font = pygame.font.SysFont('Arial', 24)
    font_small = pygame.font.SysFont('Arial', 20)

# Загрузка изображений
def load_image(name, scale=1.0):
    try:
        image = pygame.image.load(f'images/{name}.png')
        if scale != 1.0:
            new_size = (int(image.get_width() * scale), int(image.get_height() * scale))
            image = pygame.transform.scale(image, new_size)
        return image.convert_alpha()
    except:
        print(f"Не найдено изображение: images/{name}.png")
        surf = pygame.Surface((80, 80), pygame.SRCALPHA)
        if 'background' in name:
            surf.fill(DARK_BG)
        elif 'customer' in name:
            pygame.draw.circle(surf, (random.randint(100, 200), random.randint(100, 200), random.randint(100, 200)), (40, 40), 35)
        elif 'shaverma' in name:
            pygame.draw.rect(surf, ACCENT, (5, 5, 70, 70), border_radius=8)
        return surf

# Загружаем все изображения
def load_all_images():
    images = {
        'background': load_image('background'),
        'customer': load_image('customer', 0.6),
        'shaverma_classic': load_image('shaverma_classic', 0.5),
        'shaverma_spicy': load_image('shaverma_spicy', 0.5),
        'shaverma_deluxe': load_image('shaverma_deluxe', 0.5)
    }
    return images

# Музыка макана (и не только)
if not os.path.exists('music'):
    os.makedirs('music')
if not os.path.exists('images'):
    os.makedirs('images')

macan_songs = [
    "music/1.mp3",
    "music/2.mp3", 
    "music/3.mp3"
]

# Загружаем изображения
images = load_all_images()
shaverma_images = {
    'классик': images['shaverma_classic'],
    'острая': images['shaverma_spicy'],
    'делюкс': images['shaverma_deluxe']
}

# Данные игры
class Customer:
    def __init__(self, level):
        self.patience = 100 + (level * 5)
        self.order = random.choice(["классик", "острая", "делюкс"])
        self.served = False
        self.sprite = images['customer']
        self.x = -100
        self.y = 180
        self.speed = 2
        self.arrived = False

class GameData:
    def __init__(self):
        self.money = 50
        self.customers_served = 0
        self.reputation = 100
        self.level = 1
        self.xp = 0
        self.xp_to_next_level = 100
        
        # Все возможные ингредиенты
        self.all_ingredients = ['лаваш', 'мясо', 'овощи', 'соус', 'специи', 'чили']
        
        # Базовые цены
        self.base_prices = {
            'лаваш': 8,
            'мясо': 15,
            'овощи': 6,
            'соус': 5,
            'специи': 10,
            'чили': 12
        }
        
        self.ingredients = {
            'лаваш': 5,
            'мясо': 5,
            'овощи': 5,
            'соус': 4,
            'специи': 3,
            'чили': 3
        }
        
        self.base_shaverma_prices = {
            'классик': 100,
            'острая': 130,
            'делюкс': 160
        }
        
        # Рецепты шавермы
        self.recipes = {
            'классик': {'лаваш': 1, 'мясо': 1, 'овощи': 1, 'соус': 1},
            'острая': {'лаваш': 1, 'мясо': 1, 'овощи': 1, 'соус': 1, 'чили': 1},
            'делюкс': {'лаваш': 1, 'мясо': 2, 'овощи': 2, 'соус': 2, 'специи': 1}
        }
        
        # Инициализируем текущую шаверму
        self.current_shaverma = {ing: 0 for ing in self.all_ingredients}
        
        self.current_customer = None
        self.customer_timer = 0
        self.customer_interval = random.randint(8000, 15000)
        self.current_song = 0
        self.music_playing = False
        self.notification = ""
        self.notification_timer = 0
        self.cooking = False
        self.cooking_start_time = 0
        self.cooking_duration = random.randint(3, 5)

    @property
    def prices(self):
        return {ing: int(price * (1 + (self.level - 1) * 0.15)) for ing, price in self.base_prices.items()}
    
    @property
    def shaverma_prices(self):
        return {typ: int(price * (1 + (self.level - 1) * 0.25)) for typ, price in self.base_shaverma_prices.items()}

    def add_xp(self, amount):
        self.xp += amount
        if self.xp >= self.xp_to_next_level:
            self.level_up()
    
    def level_up(self):
        self.level += 1
        self.xp = 0
        self.xp_to_next_level = 100 * self.level
        show_notification(f"Уровень UP! Теперь уровень {self.level}! Цены выросли!")

    def save(self):
        with open('shaverma_save.json', 'w', encoding='utf-8') as f:
            data = self.__dict__.copy()
            if 'current_customer' in data and data['current_customer'] is not None:
                data['current_customer'] = None
            json.dump(data, f, ensure_ascii=False)
    
    def load(self):
        try:
            with open('shaverma_save.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.__dict__.update(data)
        except FileNotFoundError:
            print("Новая игра - создаем сохранение")

# Загрузка сохранения
game_data = GameData()
game_data.load()

# Функции игры
def draw_button(x, y, width, height, text, color=ACCENT, text_color=WHITE):
    pygame.draw.rect(screen, color, (x, y, width, height), border_radius=8)
    pygame.draw.rect(screen, DARK_ORANGE, (x, y, width, height), 2, border_radius=8)
    
    text_surf = font.render(text, True, text_color)
    screen.blit(text_surf, (x + width//2 - text_surf.get_width()//2, 
                          y + height//2 - text_surf.get_height()//2))
    return pygame.Rect(x, y, width, height)

def draw_panel(x, y, width, height, title_text):
    # Полупрозрачная панель
    panel = pygame.Surface((width, height), pygame.SRCALPHA)
    panel.fill(LIGHT_BG)
    pygame.draw.rect(panel, DARK_ORANGE, (0, 0, width, height), 2, border_radius=10)
    screen.blit(panel, (x, y))
    
    title = font_large.render(title_text, True, ACCENT)
    screen.blit(title, (x + 15, y - 25))
    
    return pygame.Rect(x, y, width, height)

def draw_ingredient_panel():
    panel = draw_panel(20, 100, 250, 250, "СКЛАД")
    
    y_pos = 120
    buttons = {}
    for ingredient in game_data.all_ingredients:
        amount = game_data.ingredients.get(ingredient, 0)
        price = game_data.prices.get(ingredient, 0)
        
        text = font.render(f"{ingredient}: {amount}", True, WHITE)
        screen.blit(text, (40, y_pos))
        
        price_text = font_small.render(f"${price}", True, GOLD)
        screen.blit(price_text, (180, y_pos))
        
        btn = draw_button(200, y_pos, 60, 25, "Купить", GREEN)
        buttons[ingredient] = btn
        y_pos += 35
    
    return buttons

def draw_cooking_panel():
    panel = draw_panel(290, 100, 280, 250, "ПРИГОТОВЛЕНИЕ")
    
    y_pos = 120
    buttons = {}
    
    # Кнопки добавления ингредиентов
    for ingredient in game_data.all_ingredients:
        current_amount = game_data.current_shaverma.get(ingredient, 0)
        text = font.render(f"{ingredient}: {current_amount}", True, WHITE)
        screen.blit(text, (310, y_pos))
        
        add_btn = draw_button(450, y_pos, 45, 25, "+", BLUE)
        remove_btn = draw_button(500, y_pos, 45, 25, "-", RED)
        
        buttons[f"add_{ingredient}"] = add_btn
        buttons[f"remove_{ingredient}"] = remove_btn
        y_pos += 32
    
    # Кнопка сброса
    reset_btn = draw_button(310, y_pos, 120, 30, "Сбросить", RED)
    buttons["reset"] = reset_btn
    
    # Кнопка приготовления
    if game_data.cooking:
        cook_text = f"Жарится... {max(0, game_data.cooking_duration - int(pygame.time.get_ticks()/1000 - game_data.cooking_start_time))}с"
        cook_btn = draw_button(440, y_pos, 120, 30, cook_text, ORANGE)
    else:
        cook_btn = draw_button(440, y_pos, 120, 30, "Приготовить", GREEN)
    buttons["cook"] = cook_btn
    
    return buttons

def draw_customer_panel():
    panel = draw_panel(590, 100, 280, 250, "КЛИЕНТ")
    
    if game_data.current_customer:
        # Клиент
        screen.blit(game_data.current_customer.sprite, (620, 130))
        
        # Изображение шавермы
        shaverma_img = shaverma_images.get(game_data.current_customer.order)
        if shaverma_img:
            screen.blit(shaverma_img, (700, 130))
        
        # Информация о заказе
        order_text = font.render(f"Заказ: {game_data.current_customer.order}", True, WHITE)
        screen.blit(order_text, (620, 200))
        
        patience_text = font.render(f"Терпение: {int(game_data.current_customer.patience)}%", True, 
                                 GREEN if game_data.current_customer.patience > 50 else 
                                 ACCENT if game_data.current_customer.patience > 25 else RED)
        screen.blit(patience_text, (620, 225))
        
        price = game_data.shaverma_prices.get(game_data.current_customer.order, 0)
        price_text = font.render(f"Цена: ${price}", True, GOLD)
        screen.blit(price_text, (620, 250))
        
    else:
        text = font.render("Ожидаем клиента...", True, GRAY)
        screen.blit(text, (640, 160))

def draw_stats_panel():
    panel = draw_panel(890, 100, 280, 120, "СТАТИСТИКА")
    
    stats = [
        f"Деньги: ${game_data.money}",
        f"Клиентов: {game_data.customers_served}",
        f"Уровень: {game_data.level}",
        f"Опыт: {game_data.xp}/{game_data.xp_to_next_level}"
    ]
    
    y_pos = 120
    for stat in stats:
        text = font.render(stat, True, WHITE)
        screen.blit(text, (910, y_pos))
        y_pos += 28

def draw_recipes_panel():
    panel = draw_panel(20, 370, 250, 120, "РЕЦЕПТЫ")
    
    recipes_info = [
        "🥙 Классик: лаваш,",
        "мясо, овощи, соус",
        "🌶️ Острая: классик + чили",
        "🥇 Делюкс: лаваш + 2x всё +",
        "специи"
    ]
    
    y_pos = 390
    for line in recipes_info:
        text = font_small.render(line, True, WHITE)
        screen.blit(text, (40, y_pos))
        y_pos += 20

def draw_music_panel():
    panel = draw_panel(290, 370, 280, 120, "ТОПОВЫЙ МУЗОН")
    
    track_text = font.render(f"Трек: {game_data.current_song + 1}", True, WHITE)
    screen.blit(track_text, (310, 390))
    
    next_btn = draw_button(310, 420, 110, 30, "Следующий", ACCENT)
    play_btn = draw_button(430, 420, 110, 30, "Пауза" if game_data.music_playing else "Play", 
                          RED if game_data.music_playing else GREEN)
    
    vol_text = font.render("Громкость:", True, WHITE)
    screen.blit(vol_text, (310, 460))
    
    vol_up_btn = draw_button(410, 455, 40, 30, "+", GREEN)
    vol_down_btn = draw_button(455, 455, 40, 30, "-", RED)
    
    return next_btn, play_btn, vol_up_btn, vol_down_btn

def draw_notification():
    if game_data.notification and game_data.notification_timer > 0:
        alpha = min(255, game_data.notification_timer * 2)
        text = font.render(game_data.notification, True, WHITE)
        
        surf = pygame.Surface((text.get_width() + 30, text.get_height() + 15), pygame.SRCALPHA)
        pygame.draw.rect(surf, (*ACCENT, alpha), (0, 0, surf.get_width(), surf.get_height()), border_radius=8)
        pygame.draw.rect(surf, (*DARK_ORANGE, alpha), (0, 0, surf.get_width(), surf.get_height()), 2, border_radius=8)
        
        screen.blit(surf, (WIDTH//2 - surf.get_width()//2, 20))
        screen.blit(text, (WIDTH//2 - text.get_width()//2, 25))

def show_notification(message):
    game_data.notification = message
    game_data.notification_timer = 120

def play_music():
    try:
        if os.path.exists(macan_songs[game_data.current_song]):
            mixer.music.load(macan_songs[game_data.current_song])
            mixer.music.play(-1)
            game_data.music_playing = True
            show_notification("♪ Топ музычка играет ♪")
    except:
        print("Ошибка воспроизведения музыки")
        show_notification("Ошибка воспроизведения музыки!")

def next_song():
    game_data.current_song = (game_data.current_song + 1) % len(macan_songs)
    if game_data.music_playing:
        mixer.music.stop()
        play_music()

def toggle_music():
    if game_data.music_playing:
        mixer.music.pause()
        game_data.music_playing = False
    else:
        if mixer.music.get_pos() == -1:
            play_music()
        else:
            mixer.music.unpause()
        game_data.music_playing = True

def change_volume(up=True):
    current_vol = mixer.music.get_volume()
    if up:
        new_vol = min(1.0, current_vol + 0.1)
    else:
        new_vol = max(0.0, current_vol - 0.1)
    mixer.music.set_volume(new_vol)

def spawn_customer():
    if game_data.current_customer is None:
        game_data.current_customer = Customer(game_data.level)
        show_notification("Новый клиент!")

def update_customer():
    if game_data.current_customer:
        if not game_data.current_customer.arrived:
            game_data.current_customer.x += game_data.current_customer.speed
            if game_data.current_customer.x >= 650:
                game_data.current_customer.arrived = True
        else:
            game_data.current_customer.patience -= 0.1
            if game_data.current_customer.patience <= 0:
                game_data.reputation = max(0, game_data.reputation - 5)
                game_data.current_customer = None
                show_notification("Клиент ушел!")

def add_ingredient(ingredient):
    if ingredient in game_data.ingredients and game_data.ingredients[ingredient] > 0:
        game_data.current_shaverma[ingredient] = game_data.current_shaverma.get(ingredient, 0) + 1
        game_data.ingredients[ingredient] -= 1

def remove_ingredient(ingredient):
    if ingredient in game_data.current_shaverma and game_data.current_shaverma[ingredient] > 0:
        game_data.current_shaverma[ingredient] -= 1
        game_data.ingredients[ingredient] = game_data.ingredients.get(ingredient, 0) + 1

def reset_shaverma():
    for ingredient in game_data.all_ingredients:
        current_amount = game_data.current_shaverma.get(ingredient, 0)
        if current_amount > 0:
            game_data.ingredients[ingredient] = game_data.ingredients.get(ingredient, 0) + current_amount
            game_data.current_shaverma[ingredient] = 0

def start_cooking():
    if game_data.current_customer:
        order_type = game_data.current_customer.order
        required = game_data.recipes.get(order_type, {})
        
        # Проверяем достаточно ли ингредиентов
        for ing, amount in required.items():
            if ing not in game_data.current_shaverma or game_data.current_shaverma[ing] < amount:
                show_notification(f"Не хватает {ing}!")
                return False
        
        # Начинаем жарку
        game_data.cooking = True
        game_data.cooking_start_time = pygame.time.get_ticks() / 1000
        game_data.cooking_duration = random.randint(3, 5)
        show_notification(f"Жарим шаверму! {game_data.cooking_duration}сек")
        return True
    else:
        show_notification("Нет клиентов!")
        return False

def finish_cooking():
    if game_data.current_customer:
        order_type = game_data.current_customer.order
        
        # Начисляем деньги и опыт
        price = game_data.shaverma_prices.get(order_type, 0)
        game_data.money += price
        game_data.customers_served += 1
        game_data.add_xp(price // 2)
        
        # Репутация
        game_data.reputation = min(100, game_data.reputation + 5)
        
        show_notification(f"Готово! +${price}")
        
        # Сбрасываем шаверму
        for ingredient in game_data.all_ingredients:
            game_data.current_shaverma[ingredient] = 0
        
        game_data.current_customer = None
        return True

def update_cooking():
    if game_data.cooking:
        current_time = pygame.time.get_ticks() / 1000
        elapsed = current_time - game_data.cooking_start_time
        
        if elapsed >= game_data.cooking_duration:
            game_data.cooking = False
            finish_cooking()

# Главный игровой цикл
running = True
clock = pygame.time.Clock()

try:
    play_music()
except:
    print("Не удалось запустить музыку")
    show_notification("Не удалось запустить музончик!")

while running:
    # Рисуем фон из изображения
    screen.blit(images['background'], (0, 0))
    
    # Заголовок
    title = title_font.render("Симулятор шаурмичной 🌯✅", True, ACCENT)
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 20))
    
    # Отрисовка интерфейса
    ingredient_buttons = draw_ingredient_panel()
    cooking_buttons = draw_cooking_panel()
    draw_customer_panel()
    draw_stats_panel()
    draw_recipes_panel()
    next_btn, play_btn, vol_up_btn, vol_down_btn = draw_music_panel()
    draw_notification()
    
    update_customer()
    update_cooking()
    
    game_data.customer_timer += clock.get_time()
    if game_data.customer_timer >= game_data.customer_interval:
        spawn_customer()
        game_data.customer_timer = 0
        game_data.customer_interval = random.randint(5000, 12000)
    
    if game_data.notification_timer > 0:
        game_data.notification_timer -= 1
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_data.save()
            running = False
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            
            for ingredient, button in ingredient_buttons.items():
                if button.collidepoint(mouse_pos):
                    if game_data.money >= game_data.prices.get(ingredient, 0):
                        game_data.money -= game_data.prices[ingredient]
                        game_data.ingredients[ingredient] = game_data.ingredients.get(ingredient, 0) + 1
                        show_notification(f"Куплен {ingredient}!")
                    else:
                        show_notification("Недостаточно денег!")
            
            for btn_name, button in cooking_buttons.items():
                if button.collidepoint(mouse_pos) and not game_data.cooking:
                    if btn_name.startswith("add_"):
                        ing = btn_name[4:]
                        add_ingredient(ing)
                    elif btn_name.startswith("remove_"):
                        ing = btn_name[7:]
                        remove_ingredient(ing)
                    elif btn_name == "reset":
                        reset_shaverma()
                        show_notification("Шаверма сброшена!")
                    elif btn_name == "cook":
                        start_cooking()
            
            if next_btn.collidepoint(mouse_pos):
                next_song()
            if play_btn.collidepoint(mouse_pos):
                toggle_music()
            if vol_up_btn.collidepoint(mouse_pos):
                change_volume(True)
            if vol_down_btn.collidepoint(mouse_pos):
                change_volume(False)
    
    if pygame.time.get_ticks() % 30000 < 50:
        game_data.save()
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()